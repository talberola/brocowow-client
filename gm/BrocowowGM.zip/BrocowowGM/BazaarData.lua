BrocowowGMBazaarSections = {
    {
        title = "Plate - Warrior Court",
        color = { 0.78, 0.61, 0.43 },
        npcs = {
            { entry = 200101, name = "Rixxle Edgeworth", label = "Arms Gear" },
            { entry = 200102, name = "Grimble Doublefist", label = "Fury Gear" },
            { entry = 200103, name = "Tazzik Wallbanger", label = "Protection Gear" },
            { entry = 200201, name = "Champion of the Blade", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Plate - Paladin Court",
        color = { 0.96, 0.55, 0.73 },
        npcs = {
            { entry = 200104, name = "Zeppa Lightpeddler", label = "Holy Gear" },
            { entry = 200105, name = "Fizzwick Shieldshine", label = "Protection Gear" },
            { entry = 200106, name = "Kadge Smitemonger", label = "Retribution Gear" },
            { entry = 200202, name = "Bearer of the Light", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Plate - Death Knight Court",
        color = { 0.77, 0.12, 0.23 },
        npcs = {
            { entry = 200116, name = "Morgla Gravebargain", label = "Blood Tank Gear" },
            { entry = 200117, name = "Zint Frostflog", label = "Frost Gear" },
            { entry = 200118, name = "Pox Plaguepurse", label = "Unholy Gear" },
            { entry = 200206, name = "The Frozen Herald", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Mail - Hunter Court",
        color = { 0.67, 0.83, 0.45 },
        npcs = {
            { entry = 200107, name = "Sprocketta Beastbroker", label = "Beast Mastery Gear" },
            { entry = 200108, name = "Nizzy Longsight", label = "Marksmanship Gear" },
            { entry = 200109, name = "Boomo Trapsell", label = "Survival Gear" },
            { entry = 200203, name = "Wilds Stalker", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Mail - Shaman Court",
        color = { 0.00, 0.44, 0.87 },
        npcs = {
            { entry = 200119, name = "Wizzle Stormvolt", label = "Elemental Gear" },
            { entry = 200120, name = "Draxa Fistfizz", label = "Enhancement Gear" },
            { entry = 200121, name = "Tessik Tidepeddler", label = "Restoration Gear" },
            { entry = 200207, name = "Speaker to Elements", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Leather - Rogue Court",
        color = { 1.00, 0.96, 0.41 },
        npcs = {
            { entry = 200110, name = "Vexxa Undercut", label = "Assassination Gear" },
            { entry = 200111, name = "Rukk \"Two-Blades\" Grix", label = "Combat Gear" },
            { entry = 200112, name = "Fenkle Whisperdeal", label = "Subtlety Gear" },
            { entry = 200204, name = "Shadow in the Corner", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Leather - Druid Court",
        color = { 1.00, 0.49, 0.04 },
        npcs = {
            { entry = 200128, name = "Moonie Starkspark", label = "Balance Gear" },
            { entry = 200129, name = "Brukka Ironbark", label = "Feral Tank Gear" },
            { entry = 200130, name = "Scratch Fangfee", label = "Feral DPS Gear" },
            { entry = 200131, name = "Petal Greenglimmer", label = "Restoration Gear" },
            { entry = 200210, name = "Warden of the Grove", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Cloth - Priest Court",
        color = { 1.00, 1.00, 1.00 },
        npcs = {
            { entry = 200113, name = "Mila Copperpenance", label = "Discipline Gear" },
            { entry = 200114, name = "Tindra Gleamsell", label = "Holy Gear" },
            { entry = 200115, name = "Skarn Duskhaggle", label = "Shadow Gear" },
            { entry = 200205, name = "Voice of the Light", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Cloth - Mage Court",
        color = { 0.25, 0.78, 0.92 },
        npcs = {
            { entry = 200122, name = "Ozzle Spellmark", label = "Arcane Gear" },
            { entry = 200123, name = "Cinderella Vex", label = "Fire Gear" },
            { entry = 200124, name = "Blix Coldcoin", label = "Frost Gear" },
            { entry = 200208, name = "Keeper of Secrets", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Cloth - Warlock Court",
        color = { 0.53, 0.53, 0.93 },
        npcs = {
            { entry = 200125, name = "Gazlo Painbroker", label = "Affliction Gear" },
            { entry = 200126, name = "Nefti Imphawker", label = "Demonology Gear" },
            { entry = 200127, name = "Krezz Chaosmargin", label = "Destruction Gear" },
            { entry = 200209, name = "Broker of Souls", label = "Mannequin (signage)" },
        },
    },
    {
        title = "Materials Quarter",
        color = { 0.35, 0.85, 0.70 },
        npcs = {
            { entry = 200140, name = "The Gem Sluice", label = "Gems and JC Materials" },
            { entry = 200141, name = "The Ore Stack", label = "Ore, Bars, Stone, Eternals" },
            { entry = 200142, name = "The Silken Thread", label = "Enchanting Materials" },
            { entry = 200143, name = "The Bolt & Loom", label = "Cloth, Bolts, Thread" },
            { entry = 200144, name = "The Herb Garden", label = "Herbs and Pigments" },
            { entry = 200145, name = "The Tannery", label = "Leather, Hides, Scales" },
            { entry = 200146, name = "The Tinker's Bench", label = "Engineering Parts" },
        },
    },
    {
        title = "Special Stalls",
        color = { 0.83, 0.69, 0.22 },
        npcs = {
            { entry = 200150, name = "Zaxxio", label = "Consortium Provisioner" },
            { entry = 200151, name = "Brogg the Rooster Baron", label = "Classic and TBC Mounts" },
            { entry = 200152, name = "Brogg's Chicken Handler", label = "Reserved Mount Overflow" },
            { entry = 300000, name = "Cromi", label = "Instance Reset" },
            { entry = 200159, name = "Chef Blubberfin", label = "Tuskarr Cooking Supplies" },
            { entry = 200162, name = "Lula", label = "Bolsa Família (500g bags)" },
            { entry = 31146, name = "Heroic Training Dummy", label = "Target Dummy (boss level 83)" },
            { entry = 31144, name = "Grandmaster's Training Dummy", label = "Target Dummy (level 80)" },
        },
    },
    {
        title = "Scribes & Sparkles",
        color = { 0.53, 0.75, 0.94 },
        npcs = {
            { entry = 200154, name = "Scrolla Inkfinger", label = "Weapon Enchant Scrolls" },
            { entry = 200155, name = "Vellumina Gluepot", label = "Armor Enchant Scrolls" },
            { entry = 200156, name = "Glyphberta Inksplat", label = "Glyphs: DK - Hunter" },
            { entry = 200157, name = "Scribbles McQuill", label = "Glyphs: Mage - Priest" },
            { entry = 200158, name = "Inkwell Margins", label = "Glyphs: Rogue - Warrior" },
            { entry = 200160, name = "Gorthul the Generous", label = "Soul Shards" },
            { entry = 200161, name = "Craniela Capstone", label = "Head & Shoulder Enchants" },
            { entry = 200163, name = "Pantaloona Threadwell", label = "Leg Enchants" },
        },
    },
    {
        title = "Utilities - Objects (spawn at your feet)",
        color = { 0.62, 0.62, 0.62 },
        npcs = {
            { entry = 1685, name = "Forge", label = "Object - blacksmithing", gob = true },
            { entry = 1744, name = "Anvil", label = "Object - blacksmithing", gob = true },
            { entry = 1798, name = "Campfire", label = "Object - cooking fire", gob = true },
        },
    },
}
