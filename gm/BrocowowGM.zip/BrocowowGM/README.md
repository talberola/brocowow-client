# BrocowowGM

`BrocowowGM` is the Wrath 3.3.5a GM addon for laying out the Krasus'
Landing bazaar.

## Install

Copy this entire `BrocowowGM` directory to:

`World of Warcraft/Interface/AddOns/BrocowowGM/`

At the character screen, enable **BrocowowGM**. Log in with a GM account and
type `/bazaar`.

## Bazaar workflow

1. Load the custom `creature_template` and `npc_vendor` definitions first.
   The addon places existing definitions; it does not create them.
2. Stand at the intended stall position.
3. Click **Spawn**. The server persists the creature and the addon records a
   local placement checkmark.
4. Target one of the spawned Brocowow NPCs to **Nudge to me** or
   **Delete target**. Delete requires a second confirmation click.
5. **Reset marks** clears only the addon's checklist. It never changes server
   spawns.

Delete and Nudge accept only the exact 42 entries approved in `design/03`.
Player targets, Blizzard creatures, pets, vehicles, and unknown custom NPCs
are rejected before any command is sent. Server GM permissions remain the
authority for every command.

The Props tab from `design/08` remains v2 until live chat-message GUID capture
has been verified.
