local ADDON_NAME = ...
local ROW_HEIGHT = 25
local VISIBLE_ROWS = 16
local DELETE_CONFIRM_SECONDS = 5

local displayRows = {}
local allowedEntries = {}
local panel
local scrollFrame
local visibleRows = {}
local targetLabel
local deleteButton
local pendingDeleteGUID
local pendingDeleteAt = 0

local function AddChatMessage(message)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99BrocowowGM:|r " .. message)
end

local function AddErrorMessage(message)
    UIErrorsFrame:AddMessage(message, 1.0, 0.2, 0.2, 1.0)
    AddChatMessage(message)
end

local function SendGMCommand(command)
    SendChatMessage(command, "SAY")
end

local function BuildRows()
    for _, section in ipairs(BrocowowGMBazaarSections) do
        table.insert(displayRows, {
            kind = "header",
            title = section.title,
            color = section.color,
        })
        for _, npc in ipairs(section.npcs) do
            assert(not allowedEntries[npc.entry], "Duplicate Brocowow NPC entry")
            allowedEntries[npc.entry] = npc
            table.insert(displayRows, {
                kind = "npc",
                entry = npc.entry,
                name = npc.name,
                label = npc.label,
                color = section.color,
            })
        end
    end
end

local function ParseAllowedTarget()
    local guid = UnitGUID("target")
    if type(guid) ~= "string" then
        return nil, nil
    end

    guid = string.upper(guid)
    if string.sub(guid, 1, 2) ~= "0X"
        or string.sub(guid, 3, 6) ~= "F130" then
        return nil, guid
    end

    local entryHex = string.sub(guid, 7, 12)
    if string.len(entryHex) ~= 6
        or string.find(entryHex, "[^0-9A-F]") then
        return nil, guid
    end

    local entry = tonumber(entryHex, 16)
    if not entry or not allowedEntries[entry] then
        return nil, guid
    end
    return entry, guid
end

local function ResetDeleteConfirmation()
    pendingDeleteGUID = nil
    pendingDeleteAt = 0
    if deleteButton then
        deleteButton:SetText("Delete target")
    end
end

local function UpdateTarget()
    ResetDeleteConfirmation()
    if not targetLabel then
        return
    end

    local entry = ParseAllowedTarget()
    if entry then
        local npc = allowedEntries[entry]
        targetLabel:SetText(
            string.format("Target: %s (%d)", UnitName("target") or npc.name, entry)
        )
        targetLabel:SetTextColor(0.3, 1.0, 0.3)
    elseif UnitExists("target") and not UnitIsPlayer("target") then
        targetLabel:SetText(
            string.format(
                "Target: %s (not ours -- delete only)",
                UnitName("target") or "unknown"
            )
        )
        targetLabel:SetTextColor(1.0, 0.8, 0.3)
    else
        targetLabel:SetText("Target one of our NPCs to move or delete it")
        targetLabel:SetTextColor(0.8, 0.8, 0.8)
    end
end

local function RefreshRows()
    if not scrollFrame then
        return
    end

    FauxScrollFrame_Update(
        scrollFrame,
        #displayRows,
        VISIBLE_ROWS,
        ROW_HEIGHT
    )
    local offset = FauxScrollFrame_GetOffset(scrollFrame)

    for index, rowFrame in ipairs(visibleRows) do
        local data = displayRows[offset + index]
        if not data then
            rowFrame:Hide()
        else
            rowFrame:Show()
            if data.kind == "header" then
                rowFrame.entry = nil
                rowFrame.name:SetText(data.title)
                rowFrame.name:SetTextColor(
                    data.color[1],
                    data.color[2],
                    data.color[3]
                )
                rowFrame.label:SetText("")
                rowFrame.status:SetText("")
                rowFrame.spawn:Hide()
                rowFrame.background:SetVertexColor(
                    data.color[1],
                    data.color[2],
                    data.color[3],
                    0.20
                )
            else
                rowFrame.entry = data.entry
                rowFrame.name:SetText(data.name)
                rowFrame.name:SetTextColor(1.0, 1.0, 1.0)
                rowFrame.label:SetText(
                    string.format("%s  |cff888888#%d|r", data.label, data.entry)
                )
                if BrocowowGMDB.placed[tostring(data.entry)] then
                    rowFrame.status:SetText("|cff55ff55Placed \226\156\147|r")
                else
                    rowFrame.status:SetText("")
                end
                rowFrame.spawn:Show()
                rowFrame.background:SetVertexColor(0.08, 0.08, 0.08, 0.45)
            end
        end
    end
end

local function SpawnNPC(entry)
    local def = allowedEntries[entry]
    if not def then
        AddErrorMessage("Blocked an unknown NPC entry.")
        return
    end
    -- Gameobjects (forge, anvil, campfire) spawn via .gobject add.
    SendGMCommand((def.gob and ".gobject add " or ".npc add ") .. entry)
    BrocowowGMDB.placed[tostring(entry)] = true
    RefreshRows()
    AddChatMessage("Spawn requested for " .. allowedEntries[entry].name .. ".")
end

local function DeleteTarget()
    -- v1.2: delete works on ANY targeted NPC, not just bazaar stock.
    -- Players are never deletable; the 5-second double-click confirm stays.
    if not UnitExists("target") or UnitIsPlayer("target") then
        ResetDeleteConfirmation()
        AddErrorMessage("Delete blocked: target an NPC first.")
        return
    end
    local guid = UnitGUID("target")
    local name = UnitName("target") or "the targeted NPC"

    local now = GetTime()
    if pendingDeleteGUID ~= guid
        or now - pendingDeleteAt > DELETE_CONFIRM_SECONDS then
        pendingDeleteGUID = guid
        pendingDeleteAt = now
        deleteButton:SetText("Confirm delete")
        AddChatMessage(
            "Click Confirm delete within 5 seconds to remove " .. name .. "."
        )
        return
    end

    SendGMCommand(".npc delete")
    AddChatMessage("Delete requested for " .. name .. ".")
    ResetDeleteConfirmation()
end

local function MoveTarget()
    local entry = ParseAllowedTarget()
    if not entry then
        AddErrorMessage("Move blocked: target one of the 42 approved bazaar NPCs.")
        return
    end
    SendGMCommand(".npc move")
    AddChatMessage("Move requested for " .. allowedEntries[entry].name .. ".")
end

local function ResetMarks()
    BrocowowGMDB.placed = {}
    RefreshRows()
    AddChatMessage("Local placement marks reset. Server spawns were not changed.")
end

local function CreatePanel()
    panel = CreateFrame("Frame", "BrocowowGMBazaarFrame", UIParent)
    panel:SetWidth(720)
    panel:SetHeight(570)
    panel:SetPoint("CENTER")
    panel:SetFrameStrata("DIALOG")
    panel:SetToplevel(true)
    panel:SetMovable(true)
    panel:EnableMouse(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", panel.StartMoving)
    panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
    panel:SetClampedToScreen(true)
    panel:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true,
        tileSize = 32,
        edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    panel:Hide()

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -20)
    title:SetText("Brocowow Bazaar Builder")

    local subtitle = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    subtitle:SetPoint("TOP", title, "BOTTOM", 0, -5)
    subtitle:SetText("Stand where the NPC belongs, then click Spawn")

    local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -5, -5)

    local headingName = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headingName:SetPoint("TOPLEFT", 28, -64)
    headingName:SetText("NPC")
    local headingStall = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    headingStall:SetPoint("TOPLEFT", 245, -64)
    headingStall:SetText("Stall / cluster")

    for index = 1, VISIBLE_ROWS do
        local row = CreateFrame("Frame", nil, panel)
        row:SetWidth(656)
        row:SetHeight(ROW_HEIGHT - 1)
        row:SetPoint("TOPLEFT", 25, -78 - ((index - 1) * ROW_HEIGHT))

        row.background = row:CreateTexture(nil, "BACKGROUND")
        row.background:SetAllPoints()
        row.background:SetTexture("Interface\\Buttons\\WHITE8X8")

        row.name = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.name:SetPoint("LEFT", 6, 0)
        row.name:SetWidth(210)
        row.name:SetJustifyH("LEFT")

        row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.label:SetPoint("LEFT", 220, 0)
        row.label:SetWidth(245)
        row.label:SetJustifyH("LEFT")

        row.status = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.status:SetPoint("LEFT", 468, 0)
        row.status:SetWidth(76)
        row.status:SetJustifyH("LEFT")

        row.spawn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
        row.spawn:SetWidth(82)
        row.spawn:SetHeight(21)
        row.spawn:SetPoint("RIGHT", -4, 0)
        row.spawn:SetText("Spawn")
        row.spawn:SetScript("OnClick", function()
            SpawnNPC(row.entry)
        end)
        visibleRows[index] = row
    end

    scrollFrame = CreateFrame(
        "ScrollFrame",
        "BrocowowGMBazaarScrollFrame",
        panel,
        "FauxScrollFrameTemplate"
    )
    scrollFrame:SetPoint("TOPLEFT", 25, -78)
    scrollFrame:SetPoint("BOTTOMRIGHT", -31, 92)
    scrollFrame:SetScript("OnVerticalScroll", function(self, offset)
        FauxScrollFrame_OnVerticalScroll(
            self,
            offset,
            ROW_HEIGHT,
            RefreshRows
        )
    end)

    targetLabel = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    targetLabel:SetPoint("BOTTOMLEFT", 28, 64)
    targetLabel:SetWidth(400)
    targetLabel:SetJustifyH("LEFT")

    local moveButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    moveButton:SetWidth(110)
    moveButton:SetHeight(24)
    moveButton:SetPoint("BOTTOMLEFT", 28, 27)
    moveButton:SetText("Nudge to me")
    moveButton:SetScript("OnClick", MoveTarget)

    deleteButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    deleteButton:SetWidth(120)
    deleteButton:SetHeight(24)
    deleteButton:SetPoint("LEFT", moveButton, "RIGHT", 8, 0)
    deleteButton:SetText("Delete target")
    deleteButton:SetScript("OnClick", DeleteTarget)

    local resetButton = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
    resetButton:SetWidth(105)
    resetButton:SetHeight(24)
    resetButton:SetPoint("BOTTOMRIGHT", -28, 27)
    resetButton:SetText("Reset marks")
    resetButton:SetScript("OnClick", ResetMarks)

    panel:SetScript("OnShow", function()
        RefreshRows()
        UpdateTarget()
    end)
end

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("ADDON_LOADED")
eventFrame:RegisterEvent("PLAYER_TARGET_CHANGED")
eventFrame:SetScript("OnEvent", function(self, event, arg1)
    if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
        BrocowowGMDB = BrocowowGMDB or {}
        BrocowowGMDB.placed = BrocowowGMDB.placed or {}
        BuildRows()
        CreatePanel()
        self:UnregisterEvent("ADDON_LOADED")
    elseif event == "PLAYER_TARGET_CHANGED" then
        UpdateTarget()
    end
end)

SLASH_BROCOWOWBAZAAR1 = "/bazaar"
SlashCmdList.BROCOWOWBAZAAR = function()
    if not panel then
        return
    end
    if panel:IsShown() then
        panel:Hide()
    else
        panel:Show()
    end
end
