-- BrocowowGM: bot roster (/brocobots).
-- Maps each class/spec role to ONE named bot for raid continuity. Assign a
-- bot by targeting it; Call/Dismiss send .playerbots commands. The roster
-- lives in BrocowowGMDB.botRoster (per character, survives forever).

local ROLES = {
    { key = "warrior_arms",   label = "Warrior - Arms" },
    { key = "warrior_fury",   label = "Warrior - Fury" },
    { key = "warrior_prot",   label = "Warrior - Protection" },
    { key = "paladin_holy",   label = "Paladin - Holy" },
    { key = "paladin_prot",   label = "Paladin - Protection" },
    { key = "paladin_ret",    label = "Paladin - Retribution" },
    { key = "hunter_bm",      label = "Hunter - Beast Mastery" },
    { key = "hunter_mm",      label = "Hunter - Marksmanship" },
    { key = "hunter_surv",    label = "Hunter - Survival" },
    { key = "rogue_assa",     label = "Rogue - Assassination" },
    { key = "rogue_combat",   label = "Rogue - Combat" },
    { key = "rogue_sub",      label = "Rogue - Subtlety" },
    { key = "priest_disc",    label = "Priest - Discipline" },
    { key = "priest_holy",    label = "Priest - Holy" },
    { key = "priest_shadow",  label = "Priest - Shadow" },
    { key = "dk_blood",       label = "Death Knight - Blood" },
    { key = "dk_frost",       label = "Death Knight - Frost" },
    { key = "dk_unholy",      label = "Death Knight - Unholy" },
    { key = "shaman_ele",     label = "Shaman - Elemental" },
    { key = "shaman_enh",     label = "Shaman - Enhancement" },
    { key = "shaman_resto",   label = "Shaman - Restoration" },
    { key = "mage_arcane",    label = "Mage - Arcane" },
    { key = "mage_fire",      label = "Mage - Fire" },
    { key = "mage_frost",     label = "Mage - Frost" },
    { key = "lock_affli",     label = "Warlock - Affliction" },
    { key = "lock_demo",      label = "Warlock - Demonology" },
    { key = "lock_destro",    label = "Warlock - Destruction" },
    { key = "druid_balance",  label = "Druid - Balance" },
    { key = "druid_resto",    label = "Druid - Restoration" },
    { key = "druid_feral",    label = "Druid - Feral" },
    { key = "druid_bear",     label = "Druid - Feral (Bear)" },
}

local ROW_HEIGHT = 22
local VISIBLE = 16
local panel, scroll, rows

local function Say(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99BrocowowBots:|r " .. msg)
end

local function Roster()
    BrocowowGMDB = BrocowowGMDB or {}
    BrocowowGMDB.botRoster = BrocowowGMDB.botRoster or {}
    return BrocowowGMDB.botRoster
end

local function SendBotCommand(cmd)
    SendChatMessage(cmd, "SAY")
end

local function AssignFromTarget(key)
    if not UnitExists("target") or not UnitIsPlayer("target") then
        Say("Target the bot character first.")
        return
    end
    local name = UnitName("target")
    Roster()[key] = name
    Say(key .. " -> " .. name)
    if panel and panel:IsShown() then panel.Refresh() end
end

local function CallBot(key)
    local name = Roster()[key]
    if not name then Say("No bot assigned to " .. key .. ".") return end
    SendBotCommand(".playerbots bot add " .. name)
end

local function DismissBot(key)
    local name = Roster()[key]
    if not name then return end
    SendBotCommand(".playerbots bot remove " .. name)
end

local function BuildPanel()
    panel = CreateFrame("Frame", "BrocowowBotsPanel", UIParent)
    panel:SetSize(430, VISIBLE * ROW_HEIGHT + 58)
    panel:SetPoint("CENTER")
    panel:SetBackdrop({
        bgFile = "Interface/Tooltips/UI-Tooltip-Background",
        edgeFile = "Interface/Tooltips/UI-Tooltip-Border",
        tile = true, tileSize = 16, edgeSize = 12,
        insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    panel:SetBackdropColor(0.05, 0.05, 0.05, 0.92)
    panel:SetMovable(true)
    panel:EnableMouse(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", panel.StartMoving)
    panel:SetScript("OnDragStop", panel.StopMovingOrSizing)

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", 0, -8)
    title:SetText("Brocowow Bot Roster")

    local hint = panel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOP", 0, -24)
    hint:SetText("Target a bot, click Set. Call/Off use .playerbots add/remove.")

    local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", 2, 2)

    scroll = CreateFrame("ScrollFrame", "BrocowowBotsScroll", panel,
                         "FauxScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 8, -40)
    scroll:SetPoint("BOTTOMRIGHT", -28, 10)
    scroll:SetScript("OnVerticalScroll", function(self, offset)
        FauxScrollFrame_OnVerticalScroll(self, offset, ROW_HEIGHT,
                                         panel.Refresh)
    end)

    rows = {}
    for i = 1, VISIBLE do
        local row = CreateFrame("Frame", nil, panel)
        row:SetSize(394, ROW_HEIGHT)
        row:SetPoint("TOPLEFT", 10, -40 - (i - 1) * ROW_HEIGHT)

        row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
        row.label:SetPoint("LEFT", 0, 0)
        row.label:SetWidth(150)
        row.label:SetJustifyH("LEFT")

        row.bot = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        row.bot:SetPoint("LEFT", 152, 0)
        row.bot:SetWidth(100)
        row.bot:SetJustifyH("LEFT")

        local function MakeButton(text, xofs, onClick)
            local b = CreateFrame("Button", nil, row, "UIPanelButtonTemplate2")
            b:SetSize(42, ROW_HEIGHT - 4)
            b:SetPoint("LEFT", xofs, 0)
            b:SetText(text)
            b:SetScript("OnClick", onClick)
            return b
        end
        row.setBtn = MakeButton("Set", 254, function()
            if row.key then AssignFromTarget(row.key) end
        end)
        row.callBtn = MakeButton("Call", 300, function()
            if row.key then CallBot(row.key) end
        end)
        row.offBtn = MakeButton("Off", 346, function()
            if row.key then DismissBot(row.key) end
        end)
        rows[i] = row
    end

    panel.Refresh = function()
        FauxScrollFrame_Update(scroll, #ROLES, VISIBLE, ROW_HEIGHT)
        local offset = FauxScrollFrame_GetOffset(scroll)
        for i, row in ipairs(rows) do
            local role = ROLES[offset + i]
            if role then
                row:Show()
                row.key = role.key
                row.label:SetText(role.label)
                local name = Roster()[role.key]
                if name then
                    row.bot:SetText("|cff55ff55" .. name .. "|r")
                else
                    row.bot:SetText("|cff888888unassigned|r")
                end
            else
                row:Hide()
                row.key = nil
            end
        end
    end
    panel:Hide()
end

SLASH_BROCOBOTS1 = "/brocobots"
SlashCmdList.BROCOBOTS = function(msg)
    msg = (msg or ""):gsub("^%s+", ""):gsub("%s+$", "")
    local cmd, a, b = msg:match("^(%S*)%s*(%S*)%s*(%S*)$")
    if cmd == "assign" and a ~= "" and b ~= "" then
        Roster()[a] = b
        Say(a .. " -> " .. b)
        if panel and panel:IsShown() then panel.Refresh() end
        return
    elseif cmd == "clear" and a ~= "" then
        Roster()[a] = nil
        Say(a .. " cleared.")
        if panel and panel:IsShown() then panel.Refresh() end
        return
    end
    if not panel then BuildPanel() end
    if panel:IsShown() then panel:Hide()
    else panel:Show(); panel.Refresh() end
end
