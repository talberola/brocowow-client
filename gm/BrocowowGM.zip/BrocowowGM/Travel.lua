-- Travel panel: one-click GM teleports and player summons.
-- Destinations use game_tele names verified against the production
-- acore_world.game_tele table on 2026-07-30.

local ROW_HEIGHT = 26

local DESTINATIONS = {
    { label = "Dalaran (hub)", tele = "Dalaran" },
    { label = "Naxxramas", tele = "Naxxramas" },
    { label = "Obsidian Sanctum", tele = "TheObsidianSanctum", inside = "TheObsidianSanctumInstance" },
    { label = "Eye of Eternity", tele = "TheEyeOfEternity", inside = "TheEyeOfEternityInstance" },
    { label = "Vault of Archavon", tele = "VaultOfArchavon", inside = "VaultOfArchavonInstance" },
    { label = "Ulduar", tele = "Ulduar" },
    { label = "Trial of the Crusader", tele = "TrialOfTheCrusader" },
}

local travelPanel

local function AddChatMessage(message)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99BrocowowGM:|r " .. message)
end

local function SendGMCommand(command)
    SendChatMessage(command, "SAY")
end

local function CleanPlayerName(text)
    if not text then
        return nil
    end
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    if text == "" or text:find("[^%a]") then
        return nil
    end
    return text
end

local function CreateTravelPanel()
    travelPanel = CreateFrame("Frame", "BrocowowGMTravelPanel", UIParent)
    travelPanel:SetWidth(340)
    travelPanel:SetHeight(120 + #DESTINATIONS * ROW_HEIGHT)
    travelPanel:SetPoint("CENTER", 120, 40)
    travelPanel:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    travelPanel:SetMovable(true)
    travelPanel:EnableMouse(true)
    travelPanel:RegisterForDrag("LeftButton")
    travelPanel:SetScript("OnDragStart", travelPanel.StartMoving)
    travelPanel:SetScript("OnDragStop", travelPanel.StopMovingOrSizing)
    travelPanel:Hide()
    table.insert(UISpecialFrames, "BrocowowGMTravelPanel")

    local title = travelPanel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -16)
    title:SetText("Brocowow Travel")

    local close = CreateFrame("Button", nil, travelPanel, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    for index, dest in ipairs(DESTINATIONS) do
        local y = -44 - (index - 1) * ROW_HEIGHT

        local label = travelPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
        label:SetPoint("TOPLEFT", 22, y - 4)
        label:SetText(dest.label)

        local go = CreateFrame("Button", nil, travelPanel, "UIPanelButtonTemplate")
        go:SetWidth(52)
        go:SetHeight(21)
        if dest.inside then
            go:SetPoint("TOPRIGHT", -84, y)
        else
            go:SetPoint("TOPRIGHT", -22, y)
        end
        go:SetText("Go")
        go:SetScript("OnClick", function()
            SendGMCommand(".tele " .. dest.tele)
        end)

        if dest.inside then
            local inside = CreateFrame("Button", nil, travelPanel, "UIPanelButtonTemplate")
            inside:SetWidth(58)
            inside:SetHeight(21)
            inside:SetPoint("TOPRIGHT", -22, y)
            inside:SetText("Inside")
            inside:SetScript("OnClick", function()
                SendGMCommand(".tele " .. dest.inside)
            end)
        end
    end

    local playerBoxLabel = travelPanel:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    playerBoxLabel:SetPoint("BOTTOMLEFT", 24, 52)
    playerBoxLabel:SetText("Player:")

    local playerBox = CreateFrame("EditBox", "BrocowowGMTravelName", travelPanel, "InputBoxTemplate")
    playerBox:SetWidth(120)
    playerBox:SetHeight(20)
    playerBox:SetPoint("LEFT", playerBoxLabel, "RIGHT", 10, 0)
    playerBox:SetAutoFocus(false)

    local function PlayerAction(command, verb)
        local name = CleanPlayerName(playerBox:GetText())
        if not name then
            AddChatMessage("Type a player name (letters only) first.")
            return
        end
        SendGMCommand("." .. command .. " " .. name)
        AddChatMessage(verb .. " " .. name .. ".")
    end

    local summonButton = CreateFrame("Button", nil, travelPanel, "UIPanelButtonTemplate")
    summonButton:SetWidth(75)
    summonButton:SetHeight(22)
    summonButton:SetPoint("BOTTOMRIGHT", -104, 48)
    summonButton:SetText("Summon")
    summonButton:SetScript("OnClick", function()
        PlayerAction("summon", "Summoning")
    end)

    local appearButton = CreateFrame("Button", nil, travelPanel, "UIPanelButtonTemplate")
    appearButton:SetWidth(72)
    appearButton:SetHeight(22)
    appearButton:SetPoint("LEFT", summonButton, "RIGHT", 6, 0)
    appearButton:SetText("Go to")
    appearButton:SetScript("OnClick", function()
        PlayerAction("appear", "Appearing at")
    end)

    local hint = travelPanel:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("BOTTOM", 0, 24)
    hint:SetWidth(290)
    hint:SetText("Summon pulls the player to you; Go to brings you to them.")
end

local travelEventFrame = CreateFrame("Frame")
travelEventFrame:RegisterEvent("PLAYER_LOGIN")
travelEventFrame:SetScript("OnEvent", function(self)
    if not travelPanel then
        CreateTravelPanel()
    end
    self:UnregisterEvent("PLAYER_LOGIN")
end)

SLASH_BROCOWOWTRAVEL1 = "/travel"
SlashCmdList.BROCOWOWTRAVEL = function()
    if not travelPanel then
        CreateTravelPanel()
    end
    if travelPanel:IsShown() then
        travelPanel:Hide()
    else
        travelPanel:Show()
    end
end
