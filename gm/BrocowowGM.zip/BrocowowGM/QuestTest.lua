-- QuestTest panel (/brocotest): one-click QA for every custom quest —
-- spawn the start item, teleport to each step. Coordinates verified
-- against production spawns on 2026-08-16. GM commands via chat.

local ROW_HEIGHT = 24

local function Cmd(command)
    SendChatMessage(command, "SAY")
end

-- steps: { label, "item:<id>" or "go:<x> <y> <z> <map>" }
local CHAINS = {
    { name = "Bloodsail Chart", steps = {
        { "Item", "item:1663" }, { "Chest", "go:-15009.1 259.8 0.3 0" } } },
    { name = "Powder Chart", steps = {
        { "Item", "item:4427" }, { "Chest", "go:-7915.2 -5206.1 0.7 1" } } },
    { name = "Frost Chart", steps = {
        { "Item", "item:3519" }, { "Chest", "go:-89.8 -3534.2 7.8 571" } } },
    { name = "Coffee Chart", steps = {
        { "Item", "item:1078" }, { "Chest", "go:-1352.4 -3906.7 9.1 1" } } },
    { name = "Map Fragment", steps = {
        { "Item", "item:4851" }, { "Tabetha", "go:-4031.6 -3393 39 1" },
        { "Barrel", "go:-3047.2 -4500 -19.7 1" } } },
    { name = "Singed Collar", steps = {
        { "Item", "item:200515" }, { "Alturus", "go:-11120.2 -2015.3 47.2 0" },
        { "Feedbag", "go:-11116.7 -2017.3 47.2 0" } } },
    { name = "Rooster Feather", steps = {
        { "Item", "item:20739" }, { "Saldean", "go:-10128.7 1055.2 36.4 0" },
        { "Nest", "go:-10542.8 1506.3 64 0" } } },
    { name = "Cursed Bridle", steps = {
        { "Item", "item:200517" }, { "Gravestone", "go:-7025 -2905 11 1" } } },
    { name = "Blueprint Tube", steps = {
        { "Item", "item:200518" }, { "Drazzit", "go:-4585.8 -3197.3 35.1 1" },
        { "Sled", "go:6116.8 -1082.8 402.9 571" } } },
    { name = "Library Notice", steps = {
        { "Item", "item:2793" }, { "Donathan", "go:3615.9 5961.5 136.3 571" },
        { "Tome (SM)", "go:143.3 -425.2 18.5 189" } } },
    { name = "The Undying", steps = {
        { "Zaxxio", "go:5812.7 476.8 658.8 571" } } },
    { name = "Eggs", steps = {
        { "Amber", "item:39883" }, { "Azure", "item:22288" },
        { "Twilight", "item:12241" }, { "Obsidian", "item:18965" } } },
    { name = "Eggs II", steps = {
        { "Nether", "item:18963" }, { "Gladiator", "item:18964" },
        { "Primordial", "item:18967" } } },
}

local panel

local function RunStep(spec)
    local kind, rest = spec:match("^(%a+):(.+)$")
    if kind == "item" then
        Cmd(".additem " .. rest)
    elseif kind == "go" then
        Cmd(".go xyz " .. rest)
    end
end

local function CreatePanel()
    panel = CreateFrame("Frame", "BrocowowGMQuestTestPanel", UIParent)
    panel:SetWidth(420)
    panel:SetHeight(80 + #CHAINS * ROW_HEIGHT)
    panel:SetPoint("CENTER", -140, 20)
    panel:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    panel:SetMovable(true)
    panel:EnableMouse(true)
    panel:RegisterForDrag("LeftButton")
    panel:SetScript("OnDragStart", panel.StartMoving)
    panel:SetScript("OnDragStop", panel.StopMovingOrSizing)
    panel:Hide()
    table.insert(UISpecialFrames, "BrocowowGMQuestTestPanel")

    local title = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", 0, -16)
    title:SetText("Brocowow Quest Test")

    local close = CreateFrame("Button", nil, panel, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", -6, -6)

    for i, chain in ipairs(CHAINS) do
        local y = -44 - (i - 1) * ROW_HEIGHT
        local label = panel:CreateFontString(nil, "OVERLAY", "GameFontNormal")
        label:SetPoint("TOPLEFT", 20, y - 4)
        label:SetText(chain.name)
        local x = 150
        for _, step in ipairs(chain.steps) do
            local btn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
            btn:SetWidth(62)
            btn:SetHeight(20)
            btn:SetPoint("TOPLEFT", x, y)
            btn:SetText(step[1])
            local spec = step[2]
            btn:SetScript("OnClick", function() RunStep(spec) end)
            x = x + 64
        end
    end
end

SLASH_BROCOTEST1 = "/brocotest"
SlashCmdList["BROCOTEST"] = function()
    if not panel then
        CreatePanel()
    end
    if panel:IsShown() then panel:Hide() else panel:Show() end
end
