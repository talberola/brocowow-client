-- NiceDamage for 3.3.5a: swaps the floating combat text font.
-- The font is read at login, so changes need a /reload.

local PATH = "Interface\\AddOns\\NiceDamage\\fonts\\"
local DEFAULT = "pepsi_modern.ttf"

local frame = CreateFrame("Frame")
frame:RegisterEvent("ADDON_LOADED")
frame:SetScript("OnEvent", function(_, _, name)
    if name ~= "NiceDamage" then return end
    NiceDamageDB = NiceDamageDB or {}
    local font = NiceDamageDB.font or DEFAULT
    DAMAGE_TEXT_FONT = PATH .. font
    frame:UnregisterEvent("ADDON_LOADED")
end)

local function List()
    local out = {}
    local i = 1
    while true do
        local f = ({
            "AlteHaasGroteskBold.ttf",
            "Bangers.ttf",
            "DIEDIEDI.TTF",
            "Denmark.ttf",
            "Expressway.ttf",
            "Ginko.ttf",
            "Gotham Narrow Ultra.otf",
            "LifeCraft_Font.ttf",
            "Prototype.ttf",
            "Roboto-Bold.ttf",
            "ZeroCool.ttf",
            "bignoodletitling.ttf",
            "pepsi.otf",
            "pepsi_cursive.ttf",
            "pepsi_modern.ttf",
            "pf_tempesta_seven.ttf",
            "yikes.ttf",
        })[i]
        if not f then break end
        out[i] = f
        i = i + 1
    end
    return out
end

SLASH_NICEDAMAGE1 = "/nicedamage"
SlashCmdList.NICEDAMAGE = function(msg)
    msg = (msg or ""):gsub("^%s+", ""):gsub("%s+$", "")
    NiceDamageDB = NiceDamageDB or {}
    if msg == "" or msg == "list" then
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99NiceDamage:|r current: "
            .. (NiceDamageDB.font or DEFAULT))
        for i, f in ipairs(List()) do
            DEFAULT_CHAT_FRAME:AddMessage("  " .. i .. ". " .. f)
        end
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99NiceDamage:|r /nicedamage <number> to pick, then /reload.")
        return
    end
    local idx = tonumber(msg)
    local fonts = List()
    if idx and fonts[idx] then
        NiceDamageDB.font = fonts[idx]
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99NiceDamage:|r font set to "
            .. fonts[idx] .. ". /reload to apply.")
    else
        DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99NiceDamage:|r unknown choice. /nicedamage list")
    end
end
